using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevComponents.DotNetBar;

namespace $rootnamespace$
{
	public partial class $safeitemrootname$: DevComponents.DotNetBar.Office2007RibbonForm
	{
		public $safeitemrootname$()
		{
			InitializeComponent();
		}
	}
}